#!/bin/bash
set -e

echo "🚀 HBO-Stream Deployment Script"
echo "================================"

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 1. Get Infrastructure details from Terraform
echo "🔍 Fetching Terraform outputs..."
# Adjusting this path to be relative to your 'scripts' folder
pushd ../../terraform/environments/dev > /dev/null
    EC2_IP=$(terraform output -raw ec2_public_ip 2>/dev/null)
    RDS_ENDPOINT=$(terraform output -raw rds_endpoint 2>/dev/null)
    ALB_DNS=$(terraform output -raw application_url 2>/dev/null | sed 's|http://||')
    CLOUDFRONT_URL=$(terraform output -raw cloudfront_url 2>/dev/null)
    S3_BUCKET=$(terraform output -raw s3_videos_bucket 2>/dev/null)
    SECRET_ARN=$(terraform output -raw rds_secret_arn 2>/dev/null)
popd > /dev/null

echo -e "${GREEN}✓${NC} Infrastructure details retrieved"

# 2. Get DB password
echo ""
echo "🔑 Retrieving database password..."
DB_PASSWORD=$(aws secretsmanager get-secret-value \
  --secret-id "$SECRET_ARN" \
  --query SecretString \
  --output text | jq -r .password)

if [ -z "$DB_PASSWORD" ]; then
    echo -e "${RED}✗${NC} Failed to retrieve database password"
    exit 1
fi
echo -e "${GREEN}✓${NC} Database password retrieved"

# 3. Handle Directory Logic
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARENT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
CURRENT_FOLDER_NAME=$(basename "$PARENT_DIR")

# Move to the parent directory of 'scripts'
cd "$PARENT_DIR"

# 4. Package application
# 4. Package application
echo ""
echo "📦 Packaging application..."

# Check if we are ALREADY in the 'app' folder or if 'app' is a subfolder
if [ "$CURRENT_FOLDER_NAME" == "app" ]; then
    # Added --exclude to prevent the "file changed as we read it" warning
    tar --exclude="hbo-stream-app.tar.gz" -czf hbo-stream-app.tar.gz . 
    echo -e "${GREEN}✓${NC} Application packaged (from current 'app' directory)"
elif [ -d "app" ]; then
    tar --exclude="hbo-stream-app.tar.gz" -czf hbo-stream-app.tar.gz app/
    echo -e "${GREEN}✓${NC} Application packaged (from 'app' subfolder)"
else
    echo -e "${RED}✗${NC} Error: Could not locate application files in $(pwd)"
    exit 1
fi

# 5. Upload to EC2
echo ""
echo "📤 Uploading to EC2..."
scp -i ~/.ssh/hbo-stream-key.pem \
    -o StrictHostKeyChecking=no \
    hbo-stream-app.tar.gz \
    ubuntu@${EC2_IP}:~/
echo -e "${GREEN}✓${NC} Upload complete"

# 6. Deploy on EC2
echo ""
echo "🔧 Deploying application on EC2..."
ssh -i ~/.ssh/hbo-stream-key.pem \
    -o StrictHostKeyChecking=no \
    ubuntu@${EC2_IP} << 'ENDSSH'
    set -e
    mkdir -p ~/app
    tar -xzf ~/hbo-stream-app.tar.gz -C ~/app
    cd ~/app

    echo "Restarting containers..."
    docker-compose down 2>/dev/null || true
    docker-compose build
    docker-compose up -d

    echo "=== Container Status ==="
    docker-compose ps
ENDSSH

# 7. Cleanup
rm hbo-stream-app.tar.gz

echo ""
echo -e "${GREEN}🎉 DEPLOYMENT SUCCESSFUL!${NC}"